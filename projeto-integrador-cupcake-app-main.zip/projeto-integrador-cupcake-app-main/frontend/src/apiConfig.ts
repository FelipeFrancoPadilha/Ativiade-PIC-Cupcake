// frontend/src/apiConfig.ts

// Esta é a linha de código correta para VITE.
// Ela lê a variável de ambiente VITE_API_URL.
export const API_BASE_URL = import.meta.env.VITE_API_URL;
