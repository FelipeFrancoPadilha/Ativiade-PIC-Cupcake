import React from 'react';

const Logo = () => <h1 className="text-2xl font-serif text-title">Cupcake Shop</h1>;

export default Logo;
